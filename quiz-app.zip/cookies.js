function acceptCookie(){
    document.cookie ="accepted=true ; expires=" + new Date(2021,0,1).toUTCString();
        }